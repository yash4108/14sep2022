package com.mindgate.main.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.mindgate.main.domain.JobDescriptionDetails;
import com.mindgate.main.domain.LoginDetails;

@Repository
public class LoginDetailsRepository implements LoginDetailsRepositoryInterface {

	private static final String GET_USER = "select * from login_details where User_Id=? and  Password=?";
	private static final String ADD_NEW_EMPLOYEE = "insert into login_details values(LoginSequencesSeries.NEXTVAL,?,?,?)";

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Override
	public LoginDetails getUser(LoginDetails loginDetails) {

		LoginDetails result = jdbcTemplate.queryForObject(GET_USER, new LoginDetailsRowMapper(),
				loginDetails.getUserId(), loginDetails.getPassword());

		return result;
	}

	@Override
	public boolean addLogin(LoginDetails loginDetails) {
		Object[] params = {loginDetails.getPassword(),loginDetails.getUserId(),
				loginDetails.getDesignation()};
		int result = jdbcTemplate.update(ADD_NEW_EMPLOYEE, params);
		if (result > 0) {
			System.out.println("insert success");
			return true;
		}
		return false;
	}


}
