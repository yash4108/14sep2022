package com.mindgate.main.repository;

import java.util.List;
import com.mindgate.main.domain.ProjectDetails;

public interface ProjectDetailsRepositoryInterface {

	public List<ProjectDetails> viewBudget(int projectId);

	
}
