package com.mindgate.main.domain;

import java.util.Objects;

public class ApplicantDetails {
	
	private int applicantId;
	private String applicantName;
	private String qualification;
	private String skill1;
	private String skill2;
	private String skill3;
	private int contact;
	private DocumentDetails documentDetails;
	private JobDescriptionDetails jobDescriptionDetails;
	private String status;
	
	public ApplicantDetails() {
		// TODO Auto-generated constructor stub
	}

	public ApplicantDetails(int applicantId, String applicantName, String qualification, String skill1, String skill2,
			String skill3, int contact, DocumentDetails documentDetails, JobDescriptionDetails jobDescriptionDetails,
			String status) {
		super();
		this.applicantId = applicantId;
		this.applicantName = applicantName;
		this.qualification = qualification;
		this.skill1 = skill1;
		this.skill2 = skill2;
		this.skill3 = skill3;
		this.contact = contact;
		this.documentDetails = documentDetails;
		this.jobDescriptionDetails = jobDescriptionDetails;
		this.status = status;
	}

	public int getApplicantId() {
		return applicantId;
	}

	public void setApplicantId(int applicantId) {
		this.applicantId = applicantId;
	}

	public String getApplicantName() {
		return applicantName;
	}

	public void setApplicantName(String applicantName) {
		this.applicantName = applicantName;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public String getSkill1() {
		return skill1;
	}

	public void setSkill1(String skill1) {
		this.skill1 = skill1;
	}

	public String getSkill2() {
		return skill2;
	}

	public void setSkill2(String skill2) {
		this.skill2 = skill2;
	}

	public String getSkill3() {
		return skill3;
	}

	public void setSkill3(String skill3) {
		this.skill3 = skill3;
	}

	public int getContact() {
		return contact;
	}

	public void setContact(int contact) {
		this.contact = contact;
	}

	public DocumentDetails getDocumentDetails() {
		return documentDetails;
	}

	public void setDocumentDetails(DocumentDetails documentDetails) {
		this.documentDetails = documentDetails;
	}

	public JobDescriptionDetails getJobDescriptionDetails() {
		return jobDescriptionDetails;
	}

	public void setJobDescriptionDetails(JobDescriptionDetails jobDescriptionDetails) {
		this.jobDescriptionDetails = jobDescriptionDetails;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public int hashCode() {
		return Objects.hash(applicantId, applicantName, contact, documentDetails, jobDescriptionDetails, qualification,
				skill1, skill2, skill3, status);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ApplicantDetails other = (ApplicantDetails) obj;
		return applicantId == other.applicantId && Objects.equals(applicantName, other.applicantName)
				&& contact == other.contact && Objects.equals(documentDetails, other.documentDetails)
				&& Objects.equals(jobDescriptionDetails, other.jobDescriptionDetails)
				&& Objects.equals(qualification, other.qualification) && Objects.equals(skill1, other.skill1)
				&& Objects.equals(skill2, other.skill2) && Objects.equals(skill3, other.skill3)
				&& Objects.equals(status, other.status);
	}

	@Override
	public String toString() {
		return "ApplicantDetails [applicantId=" + applicantId + ", applicantName=" + applicantName + ", qualification="
				+ qualification + ", skill1=" + skill1 + ", skill2=" + skill2 + ", skill3=" + skill3 + ", contact="
				+ contact + ", documentDetails=" + documentDetails + ", jobDescriptionDetails=" + jobDescriptionDetails
				+ ", status=" + status + "]";
	}

	
}
