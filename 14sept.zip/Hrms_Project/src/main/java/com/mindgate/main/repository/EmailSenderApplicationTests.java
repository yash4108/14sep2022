package com.mindgate.main.repository;

import org.junit.jupiter.api.Test;

@SpringBootTest
class EmailSenderApplicationTests {

	@Test
	void contextLoads() {
	}

}
