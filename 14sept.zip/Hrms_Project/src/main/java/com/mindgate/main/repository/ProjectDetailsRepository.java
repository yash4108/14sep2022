

package com.mindgate.main.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mindgate.main.domain.JobDescriptionDetails;
import com.mindgate.main.domain.LoginDetails;
import com.mindgate.main.domain.ProjectDetails;

@Repository
public class ProjectDetailsRepository implements ProjectDetailsRepositoryInterface {

	
	private static final String VIEWBUDGET=" select project_Id,project_Name,project_Cost  from project_details where project_id=?";
	@Autowired
	JdbcTemplate jdbcTemplate;
	@Override
	public List<ProjectDetails> viewBudget(int projectId) {
		// TODO Auto-generated method stub
		return jdbcTemplate.query(VIEWBUDGET, new ProjectDetailsRowMapper(),projectId);
		
	}

}




